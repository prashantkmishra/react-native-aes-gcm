import type { TurboModule } from 'react-native';
export interface Spec extends TurboModule {
    encrypt(plainText: string, key: string, saltLength: number, ivLength: number, iterationCount: number): Promise<string>;
    decrypt(encryptedText: string, key: string, saltLength: number, ivLength: number, iterationCount: number): Promise<string>;
}
declare const AesGcmModule: any;
export default AesGcmModule;
//# sourceMappingURL=NativeAesGcm.d.ts.map