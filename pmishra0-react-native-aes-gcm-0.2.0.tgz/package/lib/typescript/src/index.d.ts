type EncryptOptions = {
    saltLength?: number;
    ivLength?: number;
    iterationCount?: number;
};
export declare function encrypt(plainText: string, key: string, options?: EncryptOptions): Promise<string>;
export declare function decrypt(encryptedText: string, key: string, options?: EncryptOptions): Promise<string>;
export {};
//# sourceMappingURL=index.d.ts.map